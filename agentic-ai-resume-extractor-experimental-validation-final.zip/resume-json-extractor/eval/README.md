# Experimental Validation

This evaluation answers whether the agentic architecture earns its additional
complexity. It compares a fair non-agentic baseline with the full pipeline and
four one-component ablations.

## Dataset

`eval/dataset/` contains 50 **synthetic** resumes: 10 each of clean, messy,
multi-column-style, incomplete, and ambiguous. The current benchmark uses
text representations so the extraction task is reproducible without requiring
OCR/PDF infrastructure. The multi-column cases preserve column-order/spacing
artifacts in text; they are not claimed to be real PDF two-column files.

`ground_truth.json` is generated deterministically from the dataset generator.
It is **not described as independent human annotation**. Before submitting an
academic report that requires independently verified ground truth, have a
second reviewer independently check the JSON against the 50 source resumes
and record the reviewer/date in `ground_truth_review.md`.

## Reproducible run

```bash
pip install -r requirements.txt
export OPENAI_API_KEY=...
python -m eval.run_evaluation
python -m eval.reflection_verification_report
python -m eval.analyze_results
```

The harness runs 300 executions (50 resumes x 6 variants). It records:
- field-level accuracy across scalar, list, and nested experience/education fields
- exact-record match rate
- failure rate
- wall-clock latency
- LLM call count
- embedding call count
- input/output tokens
- estimated GPT-4.1 cost
- actual execution trace

## Variants

1. `baseline`: one GPT-4.1 extraction call, same schema.
2. `agentic_full`: all components enabled.
3. `ablation_no_reflection`: reflection disabled.
4. `ablation_no_verification`: verification disabled.
5. `ablation_no_memory`: memory disabled.
6. `ablation_no_dynamic_routing`: optional stages remain enabled, but a fixed
   control path is used so routing—not component availability—is ablated.

## Reflection / verification correctness

The correction report counts edits and then classifies each edited atomic field
as improved, regressed, or neutral relative to the matching ablation's output.
This prevents the misleading conclusion that "more corrections" automatically
means a better system.

## Memory

Memory is measured honestly. The current implementation retrieves semantic
neighbors after extraction; it therefore cannot be credited with changing an
extraction decision. If a future version moves retrieval before a decision and
logs that retrieved context was actually used, those cases can be evaluated
as causal memory interventions.

## Traces and failure analysis

`analyze_results.py` selects five actual traces from the completed run and
summarizes failures by evidence-supported root cause. Unknown cases remain
`undetermined` rather than being guessed.

## Final recommendation rule

The final report should retain, modify, or remove components only from the
measured trade-off among accuracy, failure rate, latency, calls/tokens, cost,
and complexity. No component is assumed beneficial in advance.
