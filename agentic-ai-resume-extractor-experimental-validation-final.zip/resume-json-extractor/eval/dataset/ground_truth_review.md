# Ground-truth independent review record

Status: **REVIEW REQUIRED BEFORE CLAIMING INDEPENDENT VERIFICATION**

The benchmark ground truth is generated deterministically by
`generate_dataset.py`. That guarantees reproducibility but is not the same as
independent human annotation.

For the academic submission, a second reviewer should independently compare
all 50 source resumes with `ground_truth.json` and record:

- Reviewer name:
- Review date:
- Number of resumes checked:
- Number of corrections made:
- Correction filenames/fields:
- Final reviewer sign-off:

Do not change this status to "independently verified" until that review has
actually occurred.
