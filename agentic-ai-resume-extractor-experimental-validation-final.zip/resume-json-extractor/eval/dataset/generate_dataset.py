"""
Generates a 50-resume evaluation dataset (10 per category: clean, messy,
multi-column, incomplete, ambiguous) with matching ground truth, using a
fixed random seed for full reproducibility.

Run once to (re)build the dataset:
    python eval/dataset/generate_dataset.py

This replaces the hand-written 10-resume starter set with a larger,
still-inspectable synthetic set. No API call is made - this is pure
Python, so it costs nothing to (re)generate or scale further (just
increase N_PER_CATEGORY below).
"""
import json
import random
from pathlib import Path

random.seed(42)  # reproducibility - same seed always produces the same dataset

OUT_DIR = Path(__file__).parent
N_PER_CATEGORY = 10

FIRST_NAMES = ["Ananya", "Rahul", "Priya", "Karthik", "Sneha", "Vikram", "Divya", "Arjun",
               "Kavya", "Rohan", "Meera", "Aditya", "Pooja", "Sanjay", "Nisha", "Kiran",
               "Anjali", "Suresh", "Lakshmi", "Vivek", "Deepa", "Manoj", "Swathi", "Ravi",
               "Neha", "Harish", "Shreya", "Ajay", "Radha", "Naveen", "Preethi", "Ashok",
               "Bhavana", "Girish", "Indira", "Jagan", "Kalyani", "Mahesh", "Nandini", "Omkar",
               "Padma", "Ramesh", "Sowmya", "Tarun", "Usha", "Varun", "Yamini", "Zoya",
               "Chandra", "Deepak"]
LAST_NAMES = ["Rao", "Verma", "Sharma", "Reddy", "Iyer", "Singh", "Nair", "Mehta",
              "Krishnan", "Gupta", "Menon", "Kumar", "Das", "Patel", "Joshi", "Pillai",
              "Chandra", "Bose", "Nayak", "Raju"]
COMPANIES = ["Google", "Microsoft", "Amazon", "TCS", "Infosys", "Wipro", "Accenture",
             "IBM", "Cognizant", "HCL", "Flipkart", "Zoho"]
UNIVERSITIES = ["Osmania University", "Anna University", "JNTU Hyderabad",
                "IIT Bombay", "IIT Delhi", "Delhi University", "VIT Vellore"]
SKILL_POOL = ["Python", "Java", "JavaScript", "SQL", "AWS", "Docker", "Kubernetes",
              "React", "Django", "Machine Learning", "TypeScript", "Terraform",
              "PostgreSQL", "Git", "Azure", "Spring Boot", "Tableau", "Excel"]
TITLES = ["Software Engineer", "Data Analyst", "Product Manager", "Cloud Engineer",
          "Backend Developer", "Frontend Developer", "DevOps Engineer", "Data Scientist"]
DEGREES = ["B.Tech Computer Science", "B.E Information Technology", "M.Sc Statistics",
           "M.Tech Data Science", "MBA", "B.Tech Electronics"]


def _person(i):
    first = FIRST_NAMES[i % len(FIRST_NAMES)]
    last = LAST_NAMES[i % len(LAST_NAMES)]
    email = f"{first.lower()}.{last.lower()}@example.com"
    phone = f"98765{40000 + i:05d}"[:10]
    companies = random.sample(COMPANIES, 2)
    skills = random.sample(SKILL_POOL, 4)
    university = random.choice(UNIVERSITIES)
    degree = random.choice(DEGREES)
    title = random.choice(TITLES)
    year = random.choice([2018, 2019, 2020, 2021])
    return dict(first=first, last=last, name=f"{first} {last}", email=email, phone=phone,
                companies=companies, skills=skills, university=university, degree=degree,
                title=title, year=year)


def make_clean(i):
    p = _person(i)
    text = f"""{p['name']}
Email: {p['email']}
Phone: {p['phone']}

SUMMARY
{p['title']} with experience in {p['skills'][0]} and {p['skills'][1]}.

SKILLS
{', '.join(p['skills'])}

EXPERIENCE
{p['title']}, {p['companies'][0]}
Jan {p['year']} - Present

{p['title']}, {p['companies'][1]}
Jan {p['year']-2} - Dec {p['year']-1}

EDUCATION
{p['degree']}, {p['university']}, {p['year']-1}
"""
    gt = {
        "category": "clean", "name": p["name"], "email": p["email"], "phone": p["phone"],
        "skills": p["skills"],
        "experience": [{"company": p["companies"][0]}, {"company": p["companies"][1]}],
        "education": [{"institution": p["university"]}],
    }
    return text, gt


def make_messy(i):
    p = _person(i)
    noisy_name = "  ".join(list(p["name"].upper().replace(" ", "  ")))
    text = f"""{noisy_name}
em@il: {p['email'].replace('@', ' @ ')}   ph0ne:{p['phone']}

—SUMM@RY—
{p['title']}  w1th exp   in {p['skills'][0]}  &  {p['skills'][1]}....

SK1LLS:: {','.join(p['skills']).replace(',', ',,')}

EXP3RIENCE
{p['title']}  @@  {p['companies'][0]}   (Jan{p['year']} -- present)

{p['title']}  @  {p['companies'][1]}   ({p['year']-2}-{p['year']-1})

EDU: {p['degree']} , {p['university']} ,, {p['year']-1}
"""
    gt = {
        "category": "messy", "name": p["name"], "email": p["email"], "phone": p["phone"],
        "skills": p["skills"],
        "experience": [{"company": p["companies"][0]}, {"company": p["companies"][1]}],
        "education": [{"institution": p["university"]}],
    }
    return text, gt


def make_multicolumn(i):
    p = _person(i)
    text = f"""{p['name'].upper()}
SKILLS
{p['skills'][0]}
{p['skills'][1]}
{p['email']}
{p['phone']}
EXPERIENCE
{p['title']}
{p['companies'][0]}
Jan {p['year']} - Present
EDUCATION
{p['skills'][2]}
{p['skills'][3]}
{p['degree']}
{p['university']}, {p['year']-1}
"""
    gt = {
        "category": "multicolumn", "name": p["name"], "email": p["email"], "phone": p["phone"],
        "skills": p["skills"],
        "experience": [{"company": p["companies"][0]}],
        "education": [{"institution": p["university"]}],
    }
    return text, gt


def make_incomplete(i):
    p = _person(i)
    drop_phone = i % 2 == 0  # alternate which field is missing
    text = f"""{p['name']}
{'Email: ' + p['email'] if drop_phone else 'Phone: ' + p['phone']}

Skills: {', '.join(p['skills'][:2])}

Experience:
{p['title']} - {p['companies'][0]} ({p['year']} - Present)
"""
    gt = {
        "category": "incomplete", "name": p["name"],
        "email": p["email"] if drop_phone else None,
        "phone": None if drop_phone else p["phone"],
        "skills": p["skills"][:2],
        "experience": [{"company": p["companies"][0]}],
        "education": [],
    }
    return text, gt


def make_ambiguous(i):
    p = _person(i)
    text = f"""{p['name']}
{p['email']} | phone is roughly {p['phone'][:3]} {p['phone'][3:6]} {p['phone'][6:]}

Worked at {p['companies'][0]} (some call it by a shortened name) doing
{p['title'].lower()} work, roughly since {p['year']-3} until sometime
around {p['year']-1}, then moved to a similar role at what was basically
{p['companies'][1]}, still going as of now.

Skills include things like {p['skills'][0]} and also some {p['skills'][1]}.

Studied {p['degree']} at a university, graduated around {p['year']-1} or
{p['year']}, think it was {p['university']}.
"""
    gt = {
        "category": "ambiguous", "name": p["name"], "email": p["email"], "phone": p["phone"],
        "skills": p["skills"][:2],
        "experience": [{"company": p["companies"][0]}, {"company": p["companies"][1]}],
        "education": [{"institution": p["university"]}],
        "notes": "Synthetically ambiguous: vague dates, informal company references, uncertain graduation year.",
    }
    return text, gt


GENERATORS = {
    "clean": make_clean, "messy": make_messy, "multicolumn": make_multicolumn,
    "incomplete": make_incomplete, "ambiguous": make_ambiguous,
}


def main():
    # Clear old hand-written sample files (clean_1.txt etc.) before regenerating,
    # so there's no confusion between the old 10 and the new 50.
    for old_file in OUT_DIR.glob("*.txt"):
        old_file.unlink()

    ground_truth = {}
    counter = 0
    for category, gen_fn in GENERATORS.items():
        for n in range(N_PER_CATEGORY):
            counter += 1
            text, gt = gen_fn(counter)
            filename = f"{category}_{n+1:02d}.txt"
            (OUT_DIR / filename).write_text(text, encoding="utf-8")
            ground_truth[filename] = gt

    (OUT_DIR / "ground_truth.json").write_text(
        json.dumps(ground_truth, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(f"Generated {len(ground_truth)} resumes across {len(GENERATORS)} categories into {OUT_DIR}")


if __name__ == "__main__":
    main()
